import 'package:flutter/material.dart';

class StatisticsPage extends StatelessWidget {
  const StatisticsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[600],
      appBar: AppBar(
        title: const Text('Statistics',
            style: TextStyle (fontSize: 28, fontWeight: FontWeight.bold, color: Colors.pink, ),
          textAlign: TextAlign.center,
      ),
      ),
      body: Center( // Center widget to align content in the middle
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center, // Center the content vertically
            children: [
              const Text(
                'Task Statistics',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              Card(
                elevation: 5,
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    children: [

                      const Text(
                        'Total Tasks: 20', // Placeholder for total tasks
                        style: TextStyle(fontSize: 20),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Completed Tasks: 15', // Placeholder for completed tasks
                        style: TextStyle(fontSize: 20),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'Pending Tasks: 5', // Placeholder for pending tasks
                        style: TextStyle(fontSize: 20),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context); // Navigate back to the previous page
                },
                child: const Text('Back to To-Do List'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
